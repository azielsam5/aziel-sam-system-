from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional
from uuid import uuid4

app = FastAPI()

# Allow all CORS origins for testing
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory DB (for demo only)
vouchers = {}
demo_accounts = {}

# Models
class Voucher(BaseModel):
    code: str
    expires_at: datetime
    used: bool = False

class DemoAccount(BaseModel):
    username: str
    expires_at: datetime
    active: bool = True

class CreateVoucherRequest(BaseModel):
    duration_minutes: int

class CreateDemoRequest(BaseModel):
    username: str

# Routes
@app.post("/create-voucher")
def create_voucher(req: CreateVoucherRequest):
    code = str(uuid4()).split('-')[0].upper()
    expiry = datetime.utcnow() + timedelta(minutes=req.duration_minutes)
    vouchers[code] = Voucher(code=code, expires_at=expiry)
    return {"code": code, "expires_at": expiry}

@app.get("/validate-voucher/{code}")
def validate_voucher(code: str):
    voucher = vouchers.get(code)
    if not voucher:
        raise HTTPException(status_code=404, detail="Voucher not found")
    if voucher.used or voucher.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Voucher expired or used")
    voucher.used = True
    return {"status": "valid", "expires_at": voucher.expires_at}

@app.post("/create-demo")
def create_demo(req: CreateDemoRequest):
    expiry = datetime.utcnow() + timedelta(days=7)
    demo_accounts[req.username] = DemoAccount(username=req.username, expires_at=expiry)
    return {"username": req.username, "expires_at": expiry}

@app.get("/demo-status/{username}")
def demo_status(username: str):
    demo = demo_accounts.get(username)
    if not demo or not demo.active:
        raise HTTPException(status_code=404, detail="Demo account not active")
    if demo.expires_at < datetime.utcnow():
        demo.active = False
        raise HTTPException(status_code=403, detail="Demo expired")
    return {"status": "active", "expires_at": demo.expires_at}